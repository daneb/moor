# keel evidence bundle — run 2026-10-14-003

Spec `git-push-on-host`, driver `none`, keel 0.11.1.
Started 2026-10-14T15:19:58.568460+02:00, finished 2026-10-14T15:20:19.361638+02:00.

Base commit `8c87a1157825b9d941f5b9afc59a3143fe87a633`.

## What changed

```
     2      2  .keel/keel.toml
     9      0  .keel/specs/git-push-on-host/approvals.jsonl
    90      0  .keel/specs/git-push-on-host/gates/G0.json
    95      0  .keel/specs/git-push-on-host/gates/G1.json
   108      0  .keel/specs/git-push-on-host/plan.md
   192      0  .keel/specs/git-push-on-host/spec.md
    69      0  .keel/specs/git-push-on-host/tasks.md
    46      1  cli/src/commands/mod.rs
    95     33  cli/src/commands/new_cmd.rs
    90     34  cli/src/commands/pull_cmd.rs
     8      2  cli/src/commands/run_cmd.rs
   180     20  cli/src/commands/ship_cmd.rs
    18      5  cli/src/compose.rs
    11     10  cli/src/manifest.rs
    95      0  docs/decisions/0014-git-on-host.md

15 file(s), +1108 -107 (1215 lines of churn) against 8c87a1157825b9d941f5b9afc59a3143fe87a633
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **FAIL** | 3 | 1 | 0 |

### G3 — what did not pass

- **human-verdict** (FAIL)
  - expected: a recorded human decision on the change
  - actual: none — run `keel approve git-push-on-host --stage merge`

## The record

`trajectory.jsonl` holds 27 events, one JSON object per line, in sequence order.
10783 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-10-14-003/` — run metadata, trajectory, gate results, evidence
- `git-push-on-host/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
