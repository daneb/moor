# keel evidence bundle — run 2026-10-02-003

Spec `studio-decisions`, driver `none`, keel 0.11.0.
Started 2026-10-02T08:42:09.978609+02:00, finished 2026-10-02T08:42:14.037276+02:00.

Base commit `c3c1d3d22afd99dbd815e48c9def6c4aea8ab363`.

## What changed

```
     5      5  .github/copilot-instructions.md
    26      0  .keel/chain.jsonl
     2      0  .keel/runs/2026-10-02-000/evidence/build.txt
    29      0  .keel/runs/2026-10-02-000/evidence/diff-stat.txt
  2100      0  .keel/runs/2026-10-02-000/evidence/diff.patch
     2      0  .keel/runs/2026-10-02-000/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-000/evidence/oracles.json
     8      0  .keel/runs/2026-10-02-000/evidence/ratchet.json
    14      0  .keel/runs/2026-10-02-000/evidence/test.txt
     1      0  .keel/runs/2026-10-02-000/evidence/tree.txt
    63      0  .keel/runs/2026-10-02-000/gates/G2.json
    11      0  .keel/runs/2026-10-02-000/run.json
    18      0  .keel/runs/2026-10-02-000/trajectory.jsonl
     2      0  .keel/runs/2026-10-02-001/evidence/build.txt
    40      0  .keel/runs/2026-10-02-001/evidence/diff-stat.txt
  4524      0  .keel/runs/2026-10-02-001/evidence/diff.patch
     2      0  .keel/runs/2026-10-02-001/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-001/evidence/oracles.json
     8      0  .keel/runs/2026-10-02-001/evidence/ratchet.json
    14      0  .keel/runs/2026-10-02-001/evidence/test.txt
     1      0  .keel/runs/2026-10-02-001/evidence/tree.txt
    63      0  .keel/runs/2026-10-02-001/gates/G2.json
    11      0  .keel/runs/2026-10-02-001/run.json
    20      0  .keel/runs/2026-10-02-001/trajectory.jsonl
     2      0  .keel/runs/2026-10-02-002/evidence/build.txt
    51      0  .keel/runs/2026-10-02-002/evidence/diff-stat.txt
  9385      0  .keel/runs/2026-10-02-002/evidence/diff.patch
     2      0  .keel/runs/2026-10-02-002/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-002/evidence/oracles.json
     8      0  .keel/runs/2026-10-02-002/evidence/ratchet.json
     2      0  .keel/runs/2026-10-02-002/evidence/review-test-invalidation.txt
    14      0  .keel/runs/2026-10-02-002/evidence/test.txt
     1      0  .keel/runs/2026-10-02-002/evidence/tree.txt
    36      0  .keel/runs/2026-10-02-002/gates/G2.5.json
    62      0  .keel/runs/2026-10-02-002/gates/G2.json
    31      0  .keel/runs/2026-10-02-002/gates/G3.json
    11      0  .keel/runs/2026-10-02-002/run.json
    22      0  .keel/runs/2026-10-02-002/trajectory.jsonl
     2      0  .keel/runs/2026-10-02-003/evidence/build.txt
     2      0  .keel/runs/2026-10-02-003/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-003/evidence/oracles.json
    14      0  .keel/runs/2026-10-02-003/evidence/test.txt
     9      0  .keel/runs/2026-10-02-003/run.json
    16      0  .keel/runs/2026-10-02-003/trajectory.jsonl
     1      0  .keel/specs/studio-authoring/approvals.jsonl
    90      0  .keel/specs/studio-authoring/gates/G0.json
   109      0  .keel/specs/studio-authoring/spec.md
     6      0  .keel/specs/studio-decisions/approvals.jsonl
    90      0  .keel/specs/studio-decisions/gates/G0.json
    95      0  .keel/specs/studio-decisions/gates/G1.json
   108      0  .keel/specs/studio-decisions/plan.md
     3      0  .keel/specs/studio-decisions/review-flags.txt
   110      0  .keel/specs/studio-decisions/spec.md
    63      0  .keel/specs/studio-decisions/tasks.md
    27     27  .keel/store/map/cli/src/CODEMAP.md
     5      5  .keel/store/map/cli/src/commands/CODEMAP.md
     1      1  .keel/store/map/cli/src/studio/CODEMAP.md
    48     47  .keel/store/steering/structure.md
    22     22  .kiro/steering/keel.md
    22     22  AGENTS.md
    22     22  CLAUDE.md
    72      0  cli/src/studio/mod.rs
    35      1  cli/src/studio/render.rs
   354      6  cli/src/studio/state.rs

64 file(s), +18213 -158 (18371 lines of churn) against c3c1d3d22afd99dbd815e48c9def6c4aea8ab363
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 20 events, one JSON object per line, in sequence order.
9583 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-10-02-003/` — run metadata, trajectory, gate results, evidence
- `studio-decisions/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
