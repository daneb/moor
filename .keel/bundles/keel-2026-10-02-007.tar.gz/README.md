# keel evidence bundle — run 2026-10-02-007

Spec `keel-evidence-retention`, driver `none`, keel 0.11.1.
Started 2026-10-02T11:26:39.367095+02:00, finished 2026-10-02T11:26:42.267979+02:00.

Base commit `9e9b633aa256ec5a25f88bd3100267ea5e851293`.

## What changed

```
    25     25  .github/copilot-instructions.md
    17      2  .gitignore
     -      -  .keel/bundles/keel-2026-10-02-003.tar.gz
     -      -  .keel/bundles/keel-2026-10-02-005.tar.gz
    16      0  .keel/chain.jsonl
     5      0  .keel/specs/keel-evidence-retention/approvals.jsonl
    90      0  .keel/specs/keel-evidence-retention/gates/G0.json
    95      0  .keel/specs/keel-evidence-retention/gates/G1.json
    90      0  .keel/specs/keel-evidence-retention/plan.md
     5      0  .keel/specs/keel-evidence-retention/review-flags.txt
   134      0  .keel/specs/keel-evidence-retention/spec.md
    57      0  .keel/specs/keel-evidence-retention/tasks.md
    22     22  .keel/store/map/cli/src/studio/CODEMAP.md
    24     24  .keel/store/steering/structure.md
    25     25  .kiro/steering/keel.md
    25     25  AGENTS.md
    25     25  CLAUDE.md
     9      0  Makefile
     7      0  docs/CI.md
   102      0  docs/EVIDENCE.md

20 file(s), +773 -148 (921 lines of churn) against 9e9b633aa256ec5a25f88bd3100267ea5e851293
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 19 events, one JSON object per line, in sequence order.
9803 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-10-02-007/` — run metadata, trajectory, gate results, evidence
- `keel-evidence-retention/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
