# keel evidence bundle — run 2026-10-02-005

Spec `studio-authoring`, driver `none`, keel 0.11.1.
Started 2026-10-02T11:01:48.907763+02:00, finished 2026-10-02T11:01:55.134749+02:00.

Base commit `0b7c96448c269fbe96dd2625d58cae9f06155e1e`.

## What changed

```
    31     31  .github/copilot-instructions.md
    11      0  .keel/chain.jsonl
     2      0  .keel/runs/2026-10-02-004/evidence/build.txt
    23      0  .keel/runs/2026-10-02-004/evidence/diff-stat.txt
  1775      0  .keel/runs/2026-10-02-004/evidence/diff.patch
     2      0  .keel/runs/2026-10-02-004/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-004/evidence/oracles.json
     8      0  .keel/runs/2026-10-02-004/evidence/ratchet.json
     5      0  .keel/runs/2026-10-02-004/evidence/review-test-invalidation.txt
    14      0  .keel/runs/2026-10-02-004/evidence/test.txt
     1      0  .keel/runs/2026-10-02-004/evidence/tree.txt
    36      0  .keel/runs/2026-10-02-004/gates/G2.5.json
    62      0  .keel/runs/2026-10-02-004/gates/G2.json
    31      0  .keel/runs/2026-10-02-004/gates/G3.json
    11      0  .keel/runs/2026-10-02-004/run.json
    22      0  .keel/runs/2026-10-02-004/trajectory.jsonl
     2      0  .keel/runs/2026-10-02-005/evidence/build.txt
     2      0  .keel/runs/2026-10-02-005/evidence/lint.txt
    74      0  .keel/runs/2026-10-02-005/evidence/oracles.json
    14      0  .keel/runs/2026-10-02-005/evidence/test.txt
     9      0  .keel/runs/2026-10-02-005/run.json
    16      0  .keel/runs/2026-10-02-005/trajectory.jsonl
     3      0  .keel/specs/studio-authoring/approvals.jsonl
    95      0  .keel/specs/studio-authoring/gates/G1.json
    88      0  .keel/specs/studio-authoring/plan.md
     5      0  .keel/specs/studio-authoring/review-flags.txt
     1      1  .keel/specs/studio-authoring/spec.md
    63      0  .keel/specs/studio-authoring/tasks.md
    23     23  .keel/store/map/cli/src/CODEMAP.md
    32     32  .keel/store/map/cli/src/studio/CODEMAP.md
    66     66  .keel/store/steering/structure.md
    67     67  .kiro/steering/keel.md
    57     57  AGENTS.md
    57     57  CLAUDE.md
   153      0  cli/src/studio/mod.rs
   110      0  cli/src/studio/state.rs

36 file(s), +3045 -334 (3379 lines of churn) against 0b7c96448c269fbe96dd2625d58cae9f06155e1e
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **pass** | 4 | 0 | 0 |

## The record

`trajectory.jsonl` holds 20 events, one JSON object per line, in sequence order.
9594 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-10-02-005/` — run metadata, trajectory, gate results, evidence
- `studio-authoring/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
