# keel evidence bundle — run 2026-10-14-006

Spec `drop-serde-yaml`, driver `none`, keel 0.11.1.
Started 2026-10-14T19:19:59.355779+02:00, finished 2026-10-14T19:20:29.130550+02:00.

Base commit `8c87a1157825b9d941f5b9afc59a3143fe87a633`.

## What changed

```
     6      0  .keel/specs/drop-serde-yaml/approvals.jsonl
    90      0  .keel/specs/drop-serde-yaml/gates/G0.json
    95      0  .keel/specs/drop-serde-yaml/gates/G1.json
    84      0  .keel/specs/drop-serde-yaml/plan.md
     1      0  .keel/specs/drop-serde-yaml/review-flags.txt
   125      0  .keel/specs/drop-serde-yaml/spec.md
    42      0  .keel/specs/drop-serde-yaml/tasks.md
    20     20  cli/Cargo.lock
     1      1  cli/Cargo.toml
     1      1  cli/src/commands/recipe.rs
     2      2  cli/src/commands/spec_cmd.rs
     2      2  cli/src/compose.rs
     8      8  cli/src/manifest.rs
     1      1  cli/src/session.rs

14 file(s), +478 -35 (513 lines of churn) against 8c87a1157825b9d941f5b9afc59a3143fe87a633
```

## Gates

| gate | verdict | passed | failed | blocked |
| --- | --- | --- | --- | --- |
| G2.5 | **pass** | 5 | 0 | 0 |
| G2 | **pass** | 9 | 0 | 0 |
| G3 | **FAIL** | 3 | 1 | 0 |

### G3 — what did not pass

- **human-verdict** (FAIL)
  - expected: a recorded human decision on the change
  - actual: none — run `keel approve drop-serde-yaml --stage merge`

## The record

`trajectory.jsonl` holds 22 events, one JSON object per line, in sequence order.
9741 tokens were put in front of the model across 4 injection(s).

Verify this bundle has not been edited since it was written:

```sh
keel export --verify keel-<run>.tar.gz
```

Every member's SHA-256 is recorded in `manifest.json`.

## Contents

- `README.md` — this file
- `manifest.json` — member hashes
- `2026-10-14-006/` — run metadata, trajectory, gate results, evidence
- `drop-serde-yaml/` — the spec, plan and tasks as agreed
- `steering/` — the durable context the agent was given
